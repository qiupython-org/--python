import socket
import sys
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host=socket.gethostname()
port=9999
s.connect((host,port))
a = open('1.txt','r')
r = a.read()
while True:
    data= r
    if not data:
        break
    s.send(data.encode('utf-8'))
    msg=s.recv(1024)
    if not msg:
        break
    print(msg.decode('utf-8'))
    s.close()
a = open('1.txt','w')
a.write()
